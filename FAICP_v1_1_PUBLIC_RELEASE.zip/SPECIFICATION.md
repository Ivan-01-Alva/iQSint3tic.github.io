# FAICP v1.1 recovery specification

Protocol ID: `d20db3722dfc1910d0564a3ef9bb91547d7a3989a8283c9a9eaf523b918017a7`

## Public cryptography
- Cipher: AES-256-GCM.
- AES key: exactly 32 bytes reconstructed from any 3 valid Shamir shares.
- Nonce: 12 bytes, published as lowercase hexadecimal in `nonce.hex.txt`.
- AAD: exact UTF-8/ASCII bytes `FAICP_v1.1|PROTOCOL_ID=d20db3722dfc1910d0564a3ef9bb91547d7a3989a8283c9a9eaf523b918017a7`.
- Ciphertext includes the 16-byte AES-GCM authentication tag at its end, as produced by Python cryptography AESGCM.encrypt.
- Signature: Ed25519 over the exact byte sequence `FAICP-SIGNED-V1.1\n` || AAD || `\n` || NONCE || CIPHERTEXT.

## Shamir secret sharing
- Threshold: 3 of 5.
- Field: GF(2^8) with AES irreducible polynomial x^8+x^4+x^3+x+1 (0x11b).
- Addition/subtraction: XOR.
- Each of the 32 secret-key bytes is the constant term of an independent random degree-2 polynomial.
- Share x-coordinates are 1,2,3,4,5.
- Each share stores the 32 y-values corresponding to its x-coordinate.
- Recover by Lagrange interpolation at x=0, independently for each byte.

## Return-token verification
The return message carries `RETURN_TOKEN` as 64 lowercase hexadecimal characters representing 32 raw bytes. Compute SHA-256 of those 32 raw bytes and compare it with:

`7a42dacc3980bc13c79a38d7a7f08948cfa2416d1f1dbb10ff69f203fd34e8ae`

A match authenticates knowledge of the sealed token only. It is not, by itself, evidence of backwards time communication.
