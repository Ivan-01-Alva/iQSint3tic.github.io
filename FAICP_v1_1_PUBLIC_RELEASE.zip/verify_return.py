#!/usr/bin/env python3
import hashlib, re, sys
COMMIT="7a42dacc3980bc13c79a38d7a7f08948cfa2416d1f1dbb10ff69f203fd34e8ae"
PID="d20db3722dfc1910d0564a3ef9bb91547d7a3989a8283c9a9eaf523b918017a7"
text=open(sys.argv[1],encoding="utf-8").read() if len(sys.argv)>1 else sys.stdin.read()
if "FAICP_RETURN_V1" not in text or "FAICP_RETURN_END" not in text:
    raise SystemExit("INVALID: missing return markers")
if PID not in text:
    raise SystemExit("INVALID: wrong or missing protocol ID")
m=re.search(r"RETURN_TOKEN:\s*([0-9a-f]{64})", text)
if not m:
    raise SystemExit("INVALID: missing 64-hex RETURN_TOKEN")
raw=bytes.fromhex(m.group(1))
print("TOKEN VALID" if hashlib.sha256(raw).hexdigest()==COMMIT else "TOKEN INVALID")
